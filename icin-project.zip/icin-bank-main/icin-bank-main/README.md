# icin-bank
Online banking web application to deposit, withdraw, and transfer the money between the accounts.

Features of the application:
Registration
Login
Account transactions
Transfers
Savings details
Profile settings
Requesting cheque books

Admin Portal:
It deals with all the back-end data generation and product information. The admin user can:

Authorize the roles and guidelines for the user
Grant access to the user regarding money transfer, deposits, and withdrawal
Block the user account in case of any threat
Authorize the cheque book requests


User Portal:
It deals with the user activities. The user should can:

Register or log in to the application to maintain a record of activities
Deposit and withdraw money from the account
View transactions and balance in the primary and savings account
Transfer funds between different accounts and add recipients
Request cheque books for different accounts

